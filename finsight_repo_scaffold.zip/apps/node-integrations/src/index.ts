export function ping(): string { return 'finsight-ok'; }
console.log(ping());
