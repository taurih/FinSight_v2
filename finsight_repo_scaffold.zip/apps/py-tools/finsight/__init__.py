def ping() -> str:
    return 'finsight-ok'
