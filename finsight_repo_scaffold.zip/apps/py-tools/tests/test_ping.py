from finsight import ping
def test_ping():
    assert ping() == 'finsight-ok'
